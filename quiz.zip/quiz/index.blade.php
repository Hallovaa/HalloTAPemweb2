@extends('layouts.app')

@section('title', 'List Quis')
@section('header', 'List Quis')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <a href="{{ route('quiz.create') }}" class="btn btn-primary mx-auto d-block mb-5">Tambah Quiz</a>
            <table class="table text-center">
                <thead>
                    <tr>
                        <th class="border px-4 py-2">No</th>
                        <th class="border px-4 py-2">Soal</th>
                        <th class="border px-4 py-2">Gambar</th>
                        <th class="border px-4 py-2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($quizzes as $quiz)
                    <tr>
                        <td class="border px-4 py-2">{{ $quiz->No }}</td>
                        <td class="border px-4 py-2">{{ $quiz->Soal }}</td>
                        <td class="border px-4 py-2">
                            @if($quiz->Gambar)
                                <img src="{{ asset('storage/' . $quiz->Gambar) }}" alt="{{ $quiz->No }}" style="max-width: 100px;">
                            @endif
                        </td>
                        <td class="border px-4 py-2">
                            <a href="{{ route('quiz.edit', $quiz->id) }}" class="btn btn-primary mx-2">Edit</a>
                            <form action="{{ route('quiz.destroy', $quiz->id) }}" method="POST" style="display: inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-delete" onclick="return confirm('apa anda yakin akan menghapus?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
