@extends('layouts.app')

@section('title', 'Edit Quiz')
@section('header', 'Edit Quiz')

@section('content')
<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
                <div class="card-body">
                    <form action="{{ route('quiz.update', $quiz->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="form-group row">
                            <label for="No" class="col-md-3 col-form-label">No:</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" id="No" name="No" value="{{ $quiz->No }}" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="Soal" class="col-md-3 col-form-label">Soal:</label>
                            <div class="col-md-9">
                                <textarea class="form-control" id="Soal" name="Soal" rows="4" required>{{ $quiz->Soal }}</textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="Gambar" class="col-md-3 col-form-label">Gambar:</label>
                            <div class="col-md-9">
                                <input type="file" class="form-control-file" id="Gambar" name="Gambar">
                                @if($quiz->Gambar)
                                    <img src="{{ asset('storage/' . $quiz->Gambar) }}" alt="{{ $quiz->Judul }}" class="img-thumbnail mt-2" style="max-width: 150px;">
                                @else
                                    <p class="mt-2">No file chosen</p>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row mt-3">
                            <div class="col-md-9 offset-md-3">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
