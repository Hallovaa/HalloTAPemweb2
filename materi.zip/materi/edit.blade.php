<!-- resources/views/materi/edit.blade.php -->
@extends('layouts.app')

@section('title', 'Edit Materi')

@section('header', 'Edit Materi')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 border rounded mt-2">
            <form action="{{ route('materi.update', $materi->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="mb-3 row">
                    <label for="id_input" class="col-sm-3 col-form-label">ID:</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="id_input" name="idInput" value="{{ $materi->id }}" readonly>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="judul" class="col-sm-3 col-form-label">Judul:</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="judul" name="judul" value="{{ $materi->judul }}" required>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="audio" class="col-sm-3 col-form-label">Audio:</label>
                    <div class="col-sm-9">
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="audio" name="audio" accept="audio/*">
                            <label class="custom-file-label" for="audio">Pilih file audio</label>
                        </div>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="gambar" class="col-sm-3 col-form-label">Gambar:</label>
                    <div class="col-sm-9">
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="gambar" name="gambar" accept="image/*">
                            <label class="custom-file-label" for="gambar">Pilih gambar</label>
                        </div>
                        @if($materi->gambar)
                            <img src="{{ asset('storage/' . $materi->gambar) }}" alt="{{ $materi->judul }}" class="img-thumbnail mt-2" style="max-width: 150px;">
                        @endif
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="deskripsi" class="col-sm-3 col-form-label">Deskripsi:</label>
                    <div class="col-sm-9">
                        <textarea class="form-control" id="deskripsi" name="deskripsi" required>{{ $materi->deskripsi }}</textarea>
                    </div>
                </div>
                <div class="row mx-2">
                    <button type="submit" name="submit" class="btn btn-primary col-sm-9 offset-sm-3">Edit</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
