<!-- resources/views/materi/index.blade.php -->
@extends('layouts.app')

@section('title', 'List Materi')

@section('header', 'List Materi')

@section('content')
    <a href="{{ route('materi.create') }}" class="btn btn-primary mb-3">Tambah Materi</a>

    <table class="table">
        <thead>
            <tr>
                <th>Id</th>
                <th>Judul</th>
                <th>Audio</th>
                <th>Gambar</th>
                <th>Deskripsi Materi</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($materis as $materi)
                <tr>
                    <td>{{ $materi->id }}</td>
                    <td>{{ $materi->judul }}</td>
                    <td>
                        @if($materi->audio)
                            <audio controls style="width: 100%;">
                                <source src="{{ asset('storage/' . $materi->audio) }}" type="audio/mpeg">
                            </audio>
                        @else
                            Tidak ada audio
                        @endif
                    </td>
                    <td>
                        @if($materi->Gambar)
                            <img src="{{ asset('storage/' . $materi->Gambar) }}" alt="{{ $materi->judul }}" style="max-width: 100px;">
                        @else
                            Tidak ada Gambar
                        @endif
                    </td>
                    <td>{{ $materi->deskripsi }}</td>
                    <td>
                        <div class="btn-group" role="group" aria-label="Action Buttons">
                            <a href="{{ route('materi.edit', $materi->id) }}" class="btn btn-success">Edit</a>
                            <form action="{{ route('materi.destroy', $materi->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Apa anda yakin akan menghapus?')">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
