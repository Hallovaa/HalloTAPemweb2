<!-- resources/views/materi/create.blade.php -->
@extends('layouts.app')

@section('title', 'Tambah Materi')

@section('header', 'Tambah Materi')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('materi.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group row">
                            <label for="judul" class="col-md-3 col-form-label text-md-right">Judul:</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" id="judul" name="judul" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="audio" class="col-md-3 col-form-label text-md-right">Audio:</label>
                            <div class="col-md-9">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="audio" name="audio" accept="audio/*">
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="Gambar" class="col-md-3 col-form-label text-md-right">Gambar:</label>
                            <div class="col-md-9">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="Gambar" name="Gambar" accept="image/*" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="deskripsi" class="col-md-3 col-form-label text-md-right">Deskripsi:</label>
                            <div class="col-md-9">
                                <textarea id="deskripsi" name="deskripsi" class="form-control" required></textarea>
                            </div>
                        </div>
                        <div class="form-group row mt-3">
                            <div class="col-md-3"></div>
                            <div class="col-md-9">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
